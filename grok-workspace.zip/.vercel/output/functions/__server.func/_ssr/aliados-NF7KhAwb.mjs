import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Shell, n as MailLink, r as PageIntro, t as CrisisNote } from "./site-CyOmUcbv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aliados-NF7KhAwb.js
var import_jsx_runtime = require_jsx_runtime();
var ways = [
	{
		title: "Propón una necesidad desatendida",
		body: "Cada aplicación nace de una necesidad real: del día a día, del consultorio o de la familia. Si ves un problema que nadie está resolviendo, cuéntanos. Antes de construir, lo pasamos por un filtro: ¿resuelve algo real?, ¿respeta la privacidad?, ¿evita enganchar?"
	},
	{
		title: "Participa como probador",
		body: "Antes de publicar, cada app pasa por una prueba cerrada de al menos 12 personas durante 14 días, como pide Google Play. Tu opinión nos ayuda a corregir antes de lanzar."
	},
	{
		title: "Recomiéndalas a pacientes o familias",
		body: "Cuando estén publicadas, puedes sugerirlas sabiendo que son privadas, sin anuncios engañosos y en español de México."
	}
];
function Aliados() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "Clínicas, escuelas y colegas",
		title: "Para aliados",
		lede: "Si eres clínica, escuela, colega o trabajas con familias, nos encantaría construir contigo."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-8 px-5 py-12 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-4",
				children: ways.map((way, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-paper p-5 md:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-xl font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [index + 1, ". "]
						}), way.title]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: way.body
					})]
				}, way.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-paper p-5 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold",
					children: "Lo que debes saber antes de recomendarlas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-l-4 border-pink pl-3",
							children: "Las apps de bienestar (Brisia y Brújula) no diagnostican ni sustituyen la terapia. Son un apoyo, no un tratamiento."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-l-4 border-pink pl-3",
							children: "Tienen botón de ayuda en crisis que conecta con la Línea de la Vida (800 911 2000) y con el 911."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-l-4 border-pink pl-3",
							children: "Las apps para niños (Chispa) están pensadas para usarse con un adulto presente y con consentimiento de los padres."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrisisNote, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailLink, { className: "inline-flex min-h-12 items-center font-medium underline decoration-pink underline-offset-4" }) })
		]
	})] });
}
//#endregion
export { Aliados as component };
