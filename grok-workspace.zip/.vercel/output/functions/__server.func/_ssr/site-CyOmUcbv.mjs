import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, q as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as StudioLogo, s as nav } from "./content-DLrbi3b-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-CyOmUcbv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var USER = "hola";
var HOST = ["litolabs", "app"].join(".");
/** El correo se arma en el navegador para que no quede escrito de corrido en el HTML inicial. */
function MailLink({ className }) {
	const [address, setAddress] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setAddress(`${USER}@${HOST}`);
	}, []);
	if (!address) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className,
		children: [
			USER,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				children: " [at] "
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "@"
			}),
			HOST
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className,
		href: `mailto:${address}`,
		children: address
	});
}
var linkClass = "inline-flex min-h-12 items-center rounded-full px-3 text-base font-medium";
function SiteHeader({ tone = "cream" }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const onDark = tone === "ink";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: onDark ? "on-ink bg-ink text-cream" : "border-b border-line bg-cream",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-4 md:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					"aria-label": "Lito Labs, inicio",
					className: "rounded-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, {
						tone: onDark ? "cream" : "ink",
						priority: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 md:flex",
					"aria-label": "Secciones",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						activeOptions: { exact: item.to === "/" },
						className: linkClass + (onDark ? " text-cream" : " text-ink"),
						activeProps: { className: "underline decoration-pink decoration-2 underline-offset-8" },
						children: item.label
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-12 items-center justify-center md:hidden " + (onDark ? "text-cream" : "text-ink"),
					"aria-expanded": open,
					"aria-controls": "menu-movil",
					"aria-label": open ? "Cerrar menú" : "Abrir menú",
					onClick: () => setOpen((value) => !value),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseIcon, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuIcon, {})
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "menu-movil",
			className: "border-t border-line px-5 py-3 md:hidden",
			"aria-label": "Secciones",
			children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				activeOptions: { exact: item.to === "/" },
				className: "flex min-h-12 items-center text-base font-medium " + (onDark ? "text-cream" : "text-ink"),
				activeProps: { className: "underline decoration-pink decoration-2 underline-offset-4" },
				onClick: () => setOpen(false),
				children: item.label
			}, item.to))
		}) : null]
	});
}
function ColorBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-1.5",
		"aria-hidden": "true",
		children: [
			"brisia",
			"brujula",
			"chispa",
			"tuerca",
			"prisma",
			"oficio"
		].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"data-division": key,
			className: "accent-fill h-full flex-1"
		}, key))
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "on-ink mt-16 bg-ink text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-5xl flex-col gap-8 px-5 py-12 md:flex-row md:items-center md:justify-between md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, { tone: "cream" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 md:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailLink, { className: "font-medium underline decoration-pink underline-offset-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex gap-5",
						"aria-label": "Pie de página",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacidad",
							className: "inline-flex min-h-12 items-center font-medium",
							children: "Privacidad"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contacto",
							hash: "contacto",
							className: "inline-flex min-h-12 items-center font-medium",
							children: "Contacto"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-5 pb-8 text-center text-sm text-dim md:px-8",
				children: "© 2026 Lito Labs. Hecho con calma en Tepatitlán, Jalisco."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorBar, {})
		]
	});
}
function MenuIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-6",
		fill: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M4 7h16M4 12h16M4 17h16",
			stroke: "currentColor",
			strokeWidth: "1.6",
			strokeLinecap: "round"
		})
	});
}
function CloseIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-6",
		fill: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 6l12 12M18 6 6 18",
			stroke: "currentColor",
			strokeWidth: "1.6",
			strokeLinecap: "round"
		})
	});
}
function PageIntro({ eyebrow, title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-5 py-12 md:px-8 md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium tracking-widest text-muted uppercase",
					children: eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-3xl text-4xl font-semibold leading-tight text-ink md:text-5xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-2xl text-lg text-muted",
					children: lede
				})
			]
		})
	});
}
function CrisisNote() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-2xl border border-line bg-paper p-5 md:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: "Si estás en crisis"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-muted",
			children: [
				"Estas apps no sustituyen la atención profesional. En México, la Línea de la Vida atiende las 24 horas en el",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "font-medium text-ink underline decoration-pink underline-offset-4",
					href: "tel:8009112000",
					children: "800 911 2000"
				}),
				". En una emergencia, llama al",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "font-medium text-ink underline decoration-pink underline-offset-4",
					href: "tel:911",
					children: "911"
				}),
				"."
			]
		})]
	});
}
function Shell({ tone = "cream", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cream text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:rounded-full focus:bg-ink focus:px-4 focus:py-3 focus:text-cream",
				children: "Saltar al contenido"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { tone }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Shell as i, MailLink as n, PageIntro as r, CrisisNote as t };
