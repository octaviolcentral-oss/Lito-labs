//#region node_modules/.nitro/vite/services/ssr/assets/content-CtZlX-HB.js
var statusLabel = {
	prueba: "En prueba",
	desarrollo: "En desarrollo",
	maqueta: "Maqueta",
	pausa: "Próximamente"
};
var divisions = [
	{
		slug: "brisia",
		name: "Brisia",
		kicker: "Bienestar y regulación emocional",
		purpose: "Ayudar a bajar la intensidad y a regularse en un mal momento, con herramientas sencillas y privadas.",
		audience: "Adultos que buscan calmarse, incluidas personas autistas o neurodivergentes con sobrecarga sensorial.",
		promises: [
			"Una acción grande por pantalla cuando el momento es difícil.",
			"Sin sonidos, destellos ni vibración fuerte por defecto.",
			"Textos amables, sin rachas y sin culpa.",
			"Funcionan sin conexión. Los datos se quedan en el teléfono: se exportan o se borran con un toque.",
			"Nunca llevan anuncios."
		],
		caution: "No diagnostican ni sustituyen la terapia. Son un apoyo, no un tratamiento. Si hay una crisis, la app muestra la Línea de la Vida (800 911 2000) y el 911.",
		apps: [
			{
				name: "Ancla",
				summary: "Acciones concretas para sostenerte cuando la intensidad sube.",
				status: "prueba"
			},
			{
				name: "MeltdownReset",
				summary: "Respiración guiada, lenta, para volver a tu ritmo.",
				status: "prueba"
			},
			{
				name: "SensoryMap",
				summary: "Un mapa de lugares según cómo se sienten: luz, ruido, gente.",
				status: "prueba"
			}
		]
	},
	{
		slug: "brujula",
		name: "Brújula",
		kicker: "Práctica clínica y estudio de psicología",
		purpose: "Apoyar la práctica clínica guiada y el estudio de psicología, con contenido riguroso y fuentes a la vista.",
		audience: "Psicólogos, estudiantes y adultos que practican con la guía de su terapeuta.",
		promises: [
			"Cada afirmación lleva su fuente. Nada de afirmaciones sueltas.",
			"No diagnostican ni etiquetan a la persona. No reemplazan la terapia.",
			"Sin datos de pacientes reales: ejemplos ficticios o anónimos.",
			"Si hay voz, se procesa en el teléfono.",
			"Nunca llevan anuncios."
		],
		caution: "Son material formativo o de práctica guiada, no un tratamiento. En temas sensibles, la app ofrece la Línea de la Vida (800 911 2000) y el 911.",
		apps: [{
			name: "Trato",
			summary: "Práctica de habilidades sociales, con retroalimentación neutral. Pensada para usarse junto con un terapeuta.",
			status: "prueba"
		}, {
			name: "Raíz",
			summary: "Lecturas de análisis funcional. Cada texto muestra autor y año.",
			status: "prueba"
		}]
	},
	{
		slug: "chispa",
		name: "Chispa",
		kicker: "Cuentos y juegos en familia",
		purpose: "Cuentos y juegos para disfrutar juntos, con arte original y raíces de Tepatitlán.",
		audience: "Niñas y niños con un adulto presente. La familia lee y juega junta.",
		promises: [
			"Pensadas para usarse con un adulto.",
			"Sin anuncios, sin compras escondidas y sin recolectar datos de menores.",
			"Arte original. Silencio a un toque.",
			"Botones grandes y letra clara."
		],
		apps: [{
			name: "Loto y Lito Aventura",
			summary: "Veinticuatro cuentos para leer juntos, con tiempo de lectura a la vista. Es la app más avanzada del estudio.",
			status: "prueba",
			featured: true
		}, {
			name: "Ajolote Fighters",
			summary: "Un juego de pelea con ajolotes. Sigue en desarrollo.",
			status: "desarrollo"
		}]
	},
	{
		slug: "tuerca",
		name: "Tuerca",
		kicker: "Herramientas útiles para el teléfono",
		purpose: "Herramientas que hacen una sola cosa, y la hacen bien: un teléfono más limpio, ordenado y tranquilo.",
		audience: "Cualquier persona con un teléfono Android, también quien tiene poca experiencia.",
		promises: [
			"Antes de borrar, bloquear o mover, muestran cuánto y qué va a pasar.",
			"Nada se borra ni se bloquea sin una confirmación clara. Hay papelera o deshacer.",
			"Cada permiso delicado se explica en palabras simples. Si lo niegas, la app sigue.",
			"Lo que hacen se queda en el teléfono."
		],
		apps: [
			{
				name: "Claro",
				summary: "Libera espacio y te dice cuánto soltaste, con papelera antes de borrar de verdad.",
				status: "prueba"
			},
			{
				name: "Halo",
				summary: "Baja el ruido de anuncios en el teléfono. Te explica el permiso que necesita antes de pedirlo.",
				status: "prueba"
			},
			{
				name: "Faro",
				summary: "Una pantalla de inicio sencilla, sin cajones escondidos.",
				status: "prueba"
			},
			{
				name: "Morralla",
				summary: "Práctica de microinversión en modo simulación. No mueve dinero de verdad.",
				status: "prueba"
			}
		]
	},
	{
		slug: "prisma",
		name: "Prisma",
		kicker: "Fotos y video, en orden y en privado",
		purpose: "Que las fotos y los videos estén en orden, y que lo privado se quede protegido dentro del teléfono.",
		audience: "Personas con galerías grandes que quieren orden, calma y privacidad.",
		promises: [
			"Todo se procesa en el teléfono. Las fotos privadas no salen de él.",
			"Hay papelera antes de borrar para siempre.",
			"Lo privado no se anuncia en la pantalla de inicio.",
			"Si un proceso es largo, muestra un avance real."
		],
		apps: [
			{
				name: "Nítida",
				summary: "Una galería tranquila, con papelera de 30 días.",
				status: "prueba"
			},
			{
				name: "Linde",
				summary: "Aparta en una carpeta privada, cifrada, lo que no quieres ver en la galería. Sigue en desarrollo.",
				status: "desarrollo"
			},
			{
				name: "Butaca",
				summary: "Un reproductor de video que usa los archivos que ya están en el teléfono.",
				status: "prueba"
			}
		]
	},
	{
		slug: "oficio",
		name: "Oficio",
		kicker: "Apps para negocios y su gente",
		purpose: "Herramientas de trabajo para negocios pequeños de México, escritas para que alguien las use desde el primer día.",
		audience: "Guardias, supervisores, cuadrillas de campo y quien atiende un mostrador.",
		promises: [
			"Textos sin tecnicismos y botones que se alcanzan con una mano.",
			"Lo que todavía no existe dice «Próximamente». No vendemos funciones que no están.",
			"Cada producto puede llevar su propia marca, y firma de Lito Labs."
		],
		apps: [
			{
				name: "ilux",
				summary: "Para guardias y supervisores. Sigue en desarrollo.",
				status: "desarrollo"
			},
			{
				name: "Tlali",
				summary: "Para cuadrillas que cuentan agave. Hoy es una maqueta: todavía no es una app para instalar.",
				status: "maqueta"
			},
			{
				name: "Relevo",
				summary: "Para el mostrador. Está en pausa: todavía no se construye.",
				status: "pausa"
			}
		]
	}
];
function getDivision(slug) {
	return divisions.find((division) => division.slug === slug);
}
var promises = [
	{
		title: "Privacidad",
		body: "Tus datos se quedan en tu teléfono. Sin cuentas obligatorias, sin analíticas invasivas y sin venta de datos. Pedimos solo los permisos necesarios y puedes exportar o borrar tus datos con un toque."
	},
	{
		title: "Calma",
		body: "Apps que bajan el ruido en lugar de subirlo: sin scroll infinito, sin rachas que castiguen, sin notificaciones manipuladoras, sin urgencias falsas ni culpa."
	},
	{
		title: "Honestidad",
		body: "Te decimos lo que la app hace y lo que no, qué datos usa y cuánto cuesta. Si algo no está listo, dice «Próximamente»."
	},
	{
		title: "Precios justos",
		body: "Preferimos pago único o un freemium honesto. Nada de suscripciones escondidas ni anuncios que vendan datos."
	},
	{
		title: "Accesibilidad",
		body: "Pensadas también para personas neurodivergentes, mayores o con poca experiencia, y que funcionen sin internet cuando se pueda. Una decisión por pantalla, nada de menús escondidos."
	}
];
var yesItems = [
	"Apps Android en español para nichos pequeños y desatendidos.",
	"Herramientas prácticas y privadas para el teléfono.",
	"Fotos, video y orden sin nube ni rastreo.",
	"Cuentos y juegos para disfrutar en familia.",
	"Bienestar y formación con base clínica."
];
var noItems = [
	"Apps que compiten por tu atención o buscan engancharte.",
	"Productos que recolectan o venden datos personales.",
	"Copias de apps masivas en categorías ya saturadas.",
	"Promesas que la app no puede cumplir.",
	"Lanzar más rápido de lo que podemos cuidar."
];
var nav = [
	{
		to: "/",
		label: "Inicio"
	},
	{
		to: "/divisiones",
		label: "Divisiones"
	},
	{
		to: "/estado",
		label: "Estado"
	},
	{
		to: "/aliados",
		label: "Aliados"
	},
	{
		to: "/contacto",
		label: "Contacto"
	}
];
//#endregion
export { promises as a, noItems as i, getDivision as n, statusLabel as o, nav as r, yesItems as s, divisions as t };
