import { J as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as featuredApps } from "./content-DLrbi3b-.mjs";
import { i as Shell, n as MailLink, r as PageIntro } from "./site-CyOmUcbv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contacto-CG15fy1F.js
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "mt-2 w-full rounded-xl border border-muted bg-paper px-4 py-3 text-base text-ink placeholder:text-muted";
function Contacto() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "contacto",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Tepatitlán de Morelos, Jalisco",
			title: "Contacto",
			lede: "Si quieres probar una app o contarnos una necesidad, déjanos tus datos. Te respondemos por correo."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-5 py-12 md:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "max-w-xl",
				children: [
					"También puedes escribir directo a",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailLink, { className: "font-medium underline decoration-pink underline-offset-4" }),
					"."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "relative mt-8 max-w-xl space-y-5",
				method: "POST",
				action: "https://docs.google.com/forms/d/e/REEMPLAZA_ESTE_ID/formResponse",
				target: "_blank",
				rel: "noopener noreferrer",
				onSubmit: (event) => {
					const data = new FormData(event.currentTarget);
					if (String(data.get("company") || "").trim() !== "") event.preventDefault();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "honeypot",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "company",
							children: "Empresa"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "company",
							name: "company",
							type: "text",
							tabIndex: -1,
							autoComplete: "off"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "font-medium",
						htmlFor: "nombre",
						children: "Nombre"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "nombre",
						className: fieldClass,
						name: "entry.NOMBRE",
						type: "text",
						required: true,
						autoComplete: "name"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "font-medium",
						htmlFor: "correo",
						children: "Correo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "correo",
						className: fieldClass,
						name: "entry.CORREO",
						type: "email",
						required: true,
						autoComplete: "email"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "font-medium",
						htmlFor: "dispositivo",
						children: "Dispositivo Android que usas"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "dispositivo",
						className: fieldClass,
						name: "entry.DISPOSITIVO",
						type: "text",
						required: true,
						placeholder: "Por ejemplo, Pixel 8",
						autoComplete: "off"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "font-medium",
						htmlFor: "app",
						children: "¿Qué app te interesa probar?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "app",
						className: fieldClass,
						name: "entry.APP",
						required: true,
						defaultValue: "",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							disabled: true,
							children: "Elige una"
						}), featuredApps.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: app.name,
							children: app.name
						}, app.name))]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "font-medium",
						htmlFor: "mensaje",
						children: "Mensaje"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "mensaje",
						className: fieldClass,
						name: "entry.MENSAJE",
						rows: 5,
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "acepto",
							name: "entry.PRIVACIDAD",
							type: "checkbox",
							value: "Sí",
							required: true,
							className: "mt-1 size-5 shrink-0 accent-ink"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "acepto",
							children: [
								"He leído y acepto la",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/privacidad",
									className: "font-medium underline decoration-pink underline-offset-4",
									children: "Política de Privacidad"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Al enviar tus datos, entrarás a nuestra lista de espera. Te contactaremos en cuanto se libere un nuevo cupo para la prueba cerrada de la app que elegiste."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "inline-flex min-h-12 items-center rounded-full bg-ink px-5 font-medium text-cream",
						children: "Enviar"
					})
				]
			})]
		})]
	}) });
}
//#endregion
export { Contacto as component };
