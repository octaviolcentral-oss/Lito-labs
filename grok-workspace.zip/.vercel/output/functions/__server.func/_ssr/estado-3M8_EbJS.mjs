import { o as statusLabel, t as divisions } from "./content-CtZlX-HB.mjs";
import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shell, i as PageIntro } from "./site-Cc8zQIH8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/estado-3M8_EbJS.js
var import_jsx_runtime = require_jsx_runtime();
function Estado() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "Transparencia",
		title: "Estado de las apps",
		lede: "Preferimos publicar pocas apps bien hechas y bien cuidadas que muchas a medias."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-8 px-5 py-12 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-3xl space-y-4 text-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Con toda honestidad: ninguna de nuestras apps está publicada en Google Play todavía." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Casi todas ya funcionan y están en prueba. Linde, Ajolote Fighters e ilux siguen en desarrollo. Tlali hoy es una maqueta. Relevo está en pausa." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "La más avanzada es Loto y Lito." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Antes de publicar, cada app pasa por una prueba cerrada de al menos 12 personas durante 14 días. No llamamos «lista» a una app que no se ha probado con calma." })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-8",
			children: divisions.map((division) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": `estado-${division.slug}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					id: `estado-${division.slug}`,
					className: "text-xl font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/divisiones/$slug",
						params: { slug: division.slug },
						className: "underline decoration-pink underline-offset-4",
						children: division.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-light text-muted",
						children: [" · ", division.kicker]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line rounded-2xl border border-line bg-paper",
					children: division.apps.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col gap-2 px-4 py-4 sm:flex-row sm:items-start sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: app.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: app.summary
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 text-sm font-medium",
							children: statusLabel[app.status]
						})]
					}, app.name))
				})]
			}, division.slug))
		})]
	})] });
}
//#endregion
export { Estado as component };
