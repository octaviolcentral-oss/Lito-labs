import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, q as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as featuredApps, c as noItems, d as yesItems, i as divisions, l as promises, n as DivisionMark } from "./content-DLrbi3b-.mjs";
import { i as Shell } from "./site-CyOmUcbv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CrZlhFSm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var showcase = [
	{
		slug: featuredApps[0].slug,
		badge: "Próximamente · Suscripción",
		title: featuredApps[0].name,
		division: "Oficio",
		description: "Control operativo para guardias de seguridad. Diseñada para resistir turnos completos, registrar rondas y mantener la comunicación, incluso sin conexión a internet.",
		shots: [
			{
				src: "/assets/img/mockup-ilux.webp",
				alt: "Interfaz de ilux: inicio de turno",
				width: 453,
				height: 928
			},
			{
				src: "/assets/img/mockup-ilux-2.webp",
				alt: "Interfaz de ilux: menú principal",
				width: 452,
				height: 928
			},
			{
				src: "/assets/img/mockup-ilux-3.webp",
				alt: "Interfaz de ilux: ronda con código QR",
				width: 452,
				height: 928
			}
		]
	},
	{
		slug: featuredApps[1].slug,
		badge: "En prueba cerrada",
		title: featuredApps[1].name,
		division: "Tuerca",
		description: "Un lanzador de Android que reduce el ruido digital. Con recordatorios de calma y una pantalla de inicio enfocada en lo esencial, te ayuda a recuperar tu atención.",
		shots: [
			{
				src: "/assets/img/mockup-faro.webp",
				alt: "Interfaz de Faro: pantalla de hoy",
				width: 695,
				height: 1488
			},
			{
				src: "/assets/img/mockup-faro-2.webp",
				alt: "Interfaz de Faro: pausa consciente",
				width: 695,
				height: 1488
			},
			{
				src: "/assets/img/mockup-faro-3.webp",
				alt: "Interfaz de Faro: modo noche",
				width: 695,
				height: 1488
			}
		]
	},
	{
		slug: featuredApps[2].slug,
		badge: "En prueba cerrada",
		title: featuredApps[2].name,
		division: "Chispa",
		description: "Cuentos para leer en familia, con arte original y un adulto presente. El avance se queda en el teléfono: sin anuncios y sin datos de menores.",
		shots: [
			{
				src: "/assets/img/mockup-chispa.webp",
				alt: "Interfaz de Loto y Lito: estantería de cuentos",
				width: 880,
				height: 1900
			},
			{
				src: "/assets/img/mockup-chispa-2.webp",
				alt: "Interfaz de Loto y Lito: lectura de un cuento",
				width: 880,
				height: 1900
			},
			{
				src: "/assets/img/mockup-chispa-3.webp",
				alt: "Interfaz de Loto y Lito: perfil de lectura",
				width: 880,
				height: 1900
			}
		]
	},
	{
		slug: featuredApps[3].slug,
		badge: "En prueba cerrada",
		title: featuredApps[3].name,
		division: "Oficio",
		description: "Organización de tareas y equipos de trabajo. Diseñada para funcionar sin conexión, con recordatorios locales y un enfoque en la claridad diaria. Menos ruido, más enfoque.",
		shots: [
			{
				src: "/assets/img/mockup-relevo-1.webp",
				alt: "Interfaz de Relevo: pantalla Hoy",
				width: 879,
				height: 1890
			},
			{
				src: "/assets/img/mockup-relevo-2.webp",
				alt: "Interfaz de Relevo: pantalla Semana",
				width: 879,
				height: 1890
			},
			{
				src: "/assets/img/mockup-relevo-3.webp",
				alt: "Interfaz de Relevo: día sin pendientes",
				width: 879,
				height: 1890
			}
		]
	}
];
function MockupCarousel({ shots, name }) {
	const scroller = (0, import_react.useRef)(null);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [broken, setBroken] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	function sync() {
		const el = scroller.current;
		if (!el || el.clientWidth === 0) return;
		const next = Math.round(el.scrollLeft / el.clientWidth);
		if (Number.isFinite(next)) setIndex(Math.max(0, Math.min(shots.length - 1, next)));
	}
	function go(next) {
		const el = scroller.current;
		if (!el || el.clientWidth === 0) return;
		const clamped = Math.max(0, Math.min(shots.length - 1, next));
		setIndex(clamped);
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		el.scrollTo({
			left: clamped * el.clientWidth,
			behavior: reduce ? "auto" : "smooth"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			role: "region",
			tabIndex: 0,
			className: "mockup-row",
			onScroll: sync,
			"aria-label": `Pantallas de ${name}`,
			children: shots.map((shot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mockup-slide",
				children: broken.has(shot.src) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mockup-fallback",
					children: shot.alt
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: shot.src,
					alt: shot.alt,
					width: shot.width,
					height: shot.height,
					loading: "lazy",
					decoding: "async",
					onError: () => setBroken((current) => {
						if (current.has(shot.src)) return current;
						const next = new Set(current);
						next.add(shot.src);
						return next;
					})
				})
			}, shot.src))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex items-center justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center text-ink disabled:opacity-30",
					"aria-label": `Imagen anterior de ${name}`,
					disabled: index === 0,
					onClick: () => go(index - 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, { dir: "left" })
				}),
				shots.map((shot, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center",
					"aria-label": `Imagen ${i + 1} de ${shots.length} de ${name}`,
					"aria-current": i === index ? "true" : void 0,
					onClick: () => go(i),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block size-2 rounded-full " + (i === index ? "accent-fill" : "bg-dim") })
				}, shot.src)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center text-ink disabled:opacity-30",
					"aria-label": `Siguiente imagen de ${name}`,
					disabled: index === shots.length - 1,
					onClick: () => go(index + 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, { dir: "right" })
				})
			]
		})]
	});
}
function Chevron({ dir }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 16 16",
		className: "size-4",
		fill: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: dir === "left" ? "M10 3.5 5.5 8 10 12.5" : "M6 3.5 10.5 8 6 12.5",
			stroke: "currentColor",
			strokeWidth: "1.6",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		tone: "ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "on-ink bg-ink text-cream",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 pt-8 pb-16 md:px-8 md:pt-16 md:pb-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tracking-widest text-dim uppercase",
							children: "Lito Labs · Tepatitlán, Jalisco"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-3xl text-4xl font-semibold leading-tight md:text-6xl",
							children: "Software con propósito."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-6" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-lg text-dim",
							children: "Diseñamos aplicaciones Android en español que resuelven problemas reales, respetando tu tiempo y tu privacidad."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/divisiones",
								className: "inline-flex min-h-12 items-center justify-center rounded-full bg-cream px-5 font-medium text-ink",
								children: "Ver las divisiones"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/estado",
								className: "inline-flex min-h-12 items-center justify-center rounded-full border border-dim px-5 font-medium text-cream",
								children: "Cómo van las apps"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-5xl px-5 py-14 md:px-8 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-semibold",
						children: "Quiénes somos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 max-w-3xl space-y-4 text-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Lito Labs es un estudio independiente de software con base en Tepatitlán de Morelos, Jalisco. Nacimos con una convicción clara: la tecnología debe adaptarse a las personas, no al revés." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nuestra forma de diseñar está profundamente influenciada por la psicología y el estudio del comportamiento humano. Por eso, creamos aplicaciones en español que resuelven problemas reales sin cobrar con la atención ni con los datos de quien las usa." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Una aplicación de Lito Labs se mide por si le hizo la vida más fácil a alguien, no por cuánto tiempo lo retuvo en la pantalla. Eso vale igual para ordenar el teléfono, gestionar el trabajo de un negocio, leer un cuento en familia o regularse en un momento difícil." })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-14 md:px-8 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-semibold",
							children: "Lo que te prometemos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid gap-4 md:grid-cols-2",
							children: promises.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-2xl border border-line bg-paper p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-semibold",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-muted",
									children: item.body
								})]
							}, item.title))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-14 md:px-8 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-semibold",
							children: "Seis divisiones, un mismo oficio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-lg text-muted",
							children: "Seis líneas de trabajo, un mismo cuidado. Todas firman «de Lito Labs»."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid gap-4 md:grid-cols-2",
							children: divisions.map((division) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/divisiones/$slug",
								params: { slug: division.slug },
								"data-division": division.slug,
								className: "division-card flex items-center gap-5 rounded-2xl bg-paper p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DivisionMark, { slug: division.slug }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xl font-semibold",
										children: division.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-muted",
										children: division.kicker
									})]
								})]
							}) }, division.slug))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-14 md:px-8 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-semibold",
							children: "Nuestro trabajo en marcha"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-lg text-muted",
							children: "Vistazo a nuestras apps. Creemos en mostrar el avance real. Estas son algunas de las herramientas que estamos puliendo, diseñadas bajo nuestros estándares de privacidad y calma."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid grid-cols-1 gap-4 md:grid-cols-2",
							children: showcase.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								"data-division": app.slug,
								className: "work-card flex min-w-0 flex-col p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "accent-fill w-fit rounded-full px-3 py-1 text-sm font-medium text-ink",
										children: app.badge
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "my-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MockupCarousel, {
											shots: app.shots,
											name: app.title
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-semibold text-ink",
										children: app.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "accent-text mt-1 text-sm font-medium",
										children: app.division
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-ink",
										children: app.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/contacto",
										hash: "contacto",
										className: "accent-outline mt-5 inline-flex min-h-12 items-center self-start rounded-full border px-5 font-medium",
										children: "Quiero ser probador"
									})
								]
							}, app.title))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-5xl gap-4 px-5 py-14 md:grid-cols-2 md:px-8 md:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-paper p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold",
							children: "Sí hacemos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3",
							children: yesItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-l-4 border-pink pl-3",
								children: item
							}, item))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-paper p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold",
							children: "No hacemos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3",
							children: noItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-l-4 border-line pl-3 text-muted",
								children: item
							}, item))
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-5xl px-5 py-14 md:px-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-paper p-6 md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl font-semibold",
								children: "Desarrollo en marcha"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-3xl text-lg",
								children: "Actualmente, ninguna de nuestras aplicaciones está publicada en Google Play. Casi todas ya funcionan y se encuentran en fase de prueba cerrada. Preferimos lanzar pocas apps, pero excepcionalmente bien pulidas y cuidadas."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/estado",
								className: "mt-6 inline-flex min-h-12 items-center font-medium underline decoration-pink underline-offset-4",
								children: "Ver el estado de cada app"
							})
						]
					})
				})
			})
		]
	});
}
//#endregion
export { Home as component };
