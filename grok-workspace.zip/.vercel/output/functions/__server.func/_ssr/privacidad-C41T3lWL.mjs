import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shell, i as PageIntro } from "./site-Cc8zQIH8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacidad-C41T3lWL.js
var import_jsx_runtime = require_jsx_runtime();
function Block({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-2xl font-semibold",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 max-w-3xl space-y-3 text-lg",
			children
		})
	] });
}
function Privacidad() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "Lenguaje sencillo",
		title: "Privacidad",
		lede: "Lo importante, en corto: tus datos se quedan en tu teléfono. No te rastreamos y no vendemos datos."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-10 px-5 py-12 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "En las apps",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Las apps de Lito Labs guardan la información en el teléfono. No pedimos una cuenta para usarlas." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Pedimos solo los permisos que la función necesita, y te decimos para qué. Si niegas un permiso, la app sigue con lo que pueda hacer sin él." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Puedes exportar o borrar tus datos con un toque. No hay analíticas invasivas ni anuncios que vendan datos." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cuando una app guarda algo sensible —una foto privada, por ejemplo— lo cifra en el teléfono. No lo subimos a una nube nuestra." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "La función principal está pensada para servir sin conexión, siempre que se pueda." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "Niños",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Las apps de Chispa son para usarse con un adulto presente y con consentimiento de los padres. No recolectan datos de menores, no tienen chat y no tienen compras accidentales." })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "Bienestar y consulta",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Brisia y Brújula no diagnostican ni sustituyen la terapia. No guardamos expedientes de pacientes. Los ejemplos son ficticios o anónimos." })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "Negocios",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Las apps de Oficio, cuando existan para un lugar de trabajo, dirán con claridad qué datos de otras personas manejan antes de que las uses. Hoy ninguna está publicada." })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "Este sitio",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "litolabs.com no usa analíticas, no pone cookies de rastreo y no te pide que te registres. Si nos escribes a hola@litolabs.com, usamos ese correo solo para responderte." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El sitio no vende datos porque no los recoge." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "Quién responde",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Lito Labs, estudio de Octavio Ramírez, en Tepatitlán de Morelos, Jalisco, México. Para cualquier duda de privacidad:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "font-medium text-ink underline decoration-pink underline-offset-4",
						href: "mailto:hola@litolabs.com",
						children: "hola@litolabs.com"
					}),
					"."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-base text-muted",
					children: "Texto vigente: octubre de 2026. Si cambia, lo diremos en esta página."
				})]
			})
		]
	})] });
}
//#endregion
export { Privacidad as component };
