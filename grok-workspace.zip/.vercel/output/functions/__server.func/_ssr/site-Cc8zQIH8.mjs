import { i as __toESM } from "../_runtime.mjs";
import { r as nav } from "./content-CtZlX-HB.mjs";
import { J as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-Cc8zQIH8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Axolotl({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "currentColor",
				d: "M42 34c7 .4 14 6 13 14-.4 2.4-3.2 3-5.4 1.2-2.6-4.6-7-8.2-12.2-9.2 1.6-1.8 3.2-4 4.6-6z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "30",
				cy: "42",
				rx: "15",
				ry: "10",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "26",
				cy: "33",
				rx: "14",
				ry: "12",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "18",
				cy: "51",
				rx: "4.2",
				ry: "2.1",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "34",
				cy: "51",
				rx: "4.2",
				ry: "2.1",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "var(--color-pink)",
				d: "M16 24c-1.2-7 3.4-11 6.2-5.2-2.2.2-4.2 2.2-6.2 5.2z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "var(--color-pink)",
				d: "M24 18c.2-8 6.4-10.4 7.2-3.2-2.6-.2-5.2 1-7.2 3.2z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "var(--color-pink)",
				d: "M33 20c2.2-7.2 8.6-7.4 7.4-.6-2.6-.6-5.4 0-7.4.6z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "33",
				r: "2",
				fill: "var(--color-cream)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20.6",
				cy: "33",
				r: "0.9",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16.5 39.5c2.2 2 5.6 2 7.6 0",
				fill: "none",
				stroke: "var(--color-cream)",
				strokeWidth: "1.4",
				strokeLinecap: "round"
			})
		]
	});
}
function StudioLogo({ tone = "ink" }) {
	const onDark = tone === "cream";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "slab grid size-11 place-items-center " + (onDark ? "bg-cream text-ink" : "bg-paper text-ink border border-line"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Axolotl, { className: "size-8" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-lg font-semibold tracking-tight " + (onDark ? "text-cream" : "text-ink"),
			children: "Lito Labs"
		})]
	});
}
function Glyph({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		fill: "none",
		"aria-hidden": "true",
		children
	});
}
var stroke = {
	stroke: "currentColor",
	strokeWidth: 1.8,
	strokeLinecap: "round",
	strokeLinejoin: "round"
};
function DivisionGlyph({ slug }) {
	if (slug === "brisia") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "6",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "2",
		fill: "currentColor"
	})] });
	if (slug === "brujula") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M7 12.5a6 5 0 0 1 12 0c0 3-2 4.2-4 5.2V20",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "15",
			cy: "23",
			r: "1",
			fill: "currentColor"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M18 11h6.5a4 3.4 0 0 1 0 6.8H20",
			...stroke
		})
	] });
	if (slug === "chispa") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glyph, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M13 8.5v15l11-7.5-11-7.5z",
		...stroke
	}) });
	if (slug === "tuerca") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 12h14",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "22",
			cy: "12",
			r: "2.2",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M26 20H12",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "10",
			cy: "20",
			r: "2.2",
			...stroke
		})
	] });
	if (slug === "prisma") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "6",
			y: "8",
			width: "20",
			height: "16",
			rx: "2",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 20l5.5-5 4 3.5 3-2.5 7.5 6",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "13",
			r: "1.4",
			fill: "currentColor"
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
		x: "6",
		y: "12",
		width: "20",
		height: "12",
		rx: "2",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M12 12V10a4 4 0 0 1 8 0v2",
		...stroke
	})] });
}
function AppGlyph({ name }) {
	if (name === "Ancla") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "8",
			r: "2",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 10v8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 16h12",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 16c0 6 2.2 9 4 9s4-3 4-9",
			...stroke
		})
	] });
	if (name === "MeltdownReset") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M8 18c2-6 6-8 8-8s6 2 8 8",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M10 22c1.6-4 3.4-5 6-5s4.4 1 6 5",
		...stroke
	})] });
	if (name === "SensoryMap") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M16 26s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "15",
		r: "2",
		...stroke
	})] });
	if (name === "Trato") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "3",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "21",
			cy: "13",
			r: "2.4",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 23c1-4 3.2-5.5 6-5.5s5 1.5 6 5.5",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M18 23c.6-2.6 2-3.8 4-3.8 1.6 0 2.8.8 3.6 2.4",
			...stroke
		})
	] });
	if (name === "Raíz") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 6v10",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 12c-4 1-6 4-7 8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 14c4 1 7 4 8 8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 18c-2 3-2 6-1 8M16 18c2 3 2.4 6 1.4 8",
			...stroke
		})
	] });
	if (name === "Loto y Lito Aventura") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glyph, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M8 24V10c4 2 6 2 8 0 2 2 4 2 8 0v14c-4 2-6 2-8 0-2 2-4 2-8 0z",
		...stroke
	}) });
	if (name === "Ajolote Fighters") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "5",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M12 10c0-3 2-5 4-4M16 9c1-4 4-5 5-2M19 12c3-1 6 0 6 2",
		...stroke
	})] });
	if (name === "Claro") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9 20h14",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M11 20l1.5-8h7L21 20",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M13 12V9h6v3",
			...stroke
		})
	] });
	if (name === "Halo") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "18",
		r: "5",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M10 10c1.6-2 3.6-3 6-3s4.4 1 6 3",
		...stroke
	})] });
	if (name === "Faro") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 6v3",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 12h8l2 4H10l2-4z",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M13 16v8h6v-8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 24h12",
			...stroke
		})
	] });
	if (name === "Morralla") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
		cx: "16",
		cy: "16",
		rx: "8",
		ry: "8",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M16 12v8M13.5 14.2h4.2a2 2 0 0 1 0 4H14",
		...stroke
	})] });
	if (name === "Nítida") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "4",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "8",
		...stroke
	})] });
	if (name === "Linde") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M11 24V8h8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "22",
			cy: "11",
			r: "3",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M22 8v1.2",
			...stroke
		})
	] });
	if (name === "Butaca") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M9 14h14v6a4 4 0 0 1-4 4H13a4 4 0 0 1-4-4v-6z",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M9 16V12a3 3 0 0 1 3-3h8",
		...stroke
	})] });
	if (name === "ilux") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 20h20",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M8 20l6-8 4 4 3-3 5 7",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "22",
			cy: "10",
			r: "2",
			...stroke
		})
	] });
	if (name === "Tlali") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 24V14",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 16c-2-4-6-5-8-3 3 0 5 2 8 3z",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 14c2-5 7-6 9-3-3 0-6 2-9 3z",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 20c-3-2-6-2-8 0",
			...stroke
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M8 20h16M10 20V12h12v8",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M13 12V9h6v3",
		...stroke
	})] });
}
function DivisionMark({ slug }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		"data-division": slug,
		className: "relative inline-block size-20 shrink-0",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 96 96",
			className: "size-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "28",
					cy: "22",
					rx: "5",
					ry: "10",
					fill: "var(--accent)",
					transform: "rotate(-22 28 22)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "46",
					cy: "18",
					rx: "5",
					ry: "11",
					fill: "var(--accent)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "64",
					cy: "22",
					rx: "5",
					ry: "10",
					fill: "var(--accent)",
					transform: "rotate(22 64 22)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "18",
					y: "32",
					width: "56",
					height: "56",
					rx: "15",
					fill: "var(--color-ink)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					fill: "var(--accent)",
					d: "M70 52c14-1 20 12 14 26-7-8-12-16-14-24z"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute inset-0 flex items-end justify-center pb-4 text-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DivisionGlyph, { slug })
		})]
	});
}
function AppMark({ division, name }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		"data-division": division,
		className: "slab relative grid size-14 shrink-0 place-items-center bg-ink text-cream",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppGlyph, { name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "accent-fill absolute right-1.5 bottom-1.5 size-1.5 rounded-full" })]
	});
}
var linkClass = "inline-flex min-h-12 items-center rounded-full px-3 text-base font-medium";
function SiteHeader({ tone = "cream" }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const onDark = tone === "ink";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: onDark ? "on-ink bg-ink text-cream" : "border-b border-line bg-cream",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-4 md:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					"aria-label": "Lito Labs, inicio",
					className: "rounded-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, { tone: onDark ? "cream" : "ink" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 md:flex",
					"aria-label": "Secciones",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						activeOptions: { exact: item.to === "/" },
						className: linkClass + (onDark ? " text-cream" : " text-ink"),
						activeProps: { className: "underline decoration-pink decoration-2 underline-offset-8" },
						children: item.label
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex min-h-12 items-center rounded-full border px-4 text-sm font-medium md:hidden " + (onDark ? "border-dim text-cream" : "border-line text-ink"),
					"aria-expanded": open,
					"aria-controls": "menu-movil",
					onClick: () => setOpen((value) => !value),
					children: open ? "Cerrar" : "Menú"
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "menu-movil",
			className: "border-t border-line px-5 py-3 md:hidden",
			"aria-label": "Secciones",
			children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				activeOptions: { exact: item.to === "/" },
				className: "flex min-h-12 items-center text-base font-medium " + (onDark ? "text-cream" : "text-ink"),
				activeProps: { className: "underline decoration-pink decoration-2 underline-offset-4" },
				onClick: () => setOpen(false),
				children: item.label
			}, item.to))
		}) : null]
	});
}
function ColorBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-1.5",
		"aria-hidden": "true",
		children: [
			"brisia",
			"brujula",
			"chispa",
			"tuerca",
			"prisma",
			"oficio"
		].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"data-division": key,
			className: "accent-fill h-full flex-1"
		}, key))
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-8 border-t border-line",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-5xl gap-8 px-5 py-12 md:grid-cols-3 md:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xs text-muted",
						children: "Estudio de apps Android en español. Tepatitlán de Morelos, Jalisco."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium tracking-wide",
						children: "Mapa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-1",
						children: [nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "inline-flex min-h-11 items-center text-ink",
							children: item.label
						}) }, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacidad",
							className: "inline-flex min-h-11 items-center text-ink",
							children: "Privacidad"
						}) })]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium tracking-wide",
							children: "Contacto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "font-medium underline decoration-pink underline-offset-4",
								href: "mailto:hola@litolabs.com",
								children: "hola@litolabs.com"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "Teléfono: próximamente"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "litolabs.com"
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-5 pb-6 text-center text-sm text-muted md:px-8",
				children: "Todas las apps firman «de Lito Labs» con el mismo ajolote."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorBar, {})
		]
	});
}
function PageIntro({ eyebrow, title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-5 py-12 md:px-8 md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium tracking-widest text-muted uppercase",
					children: eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-3xl text-4xl font-semibold leading-tight text-ink md:text-5xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-2xl text-lg text-muted",
					children: lede
				})
			]
		})
	});
}
function CrisisNote() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-2xl border border-line bg-paper p-5 md:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: "Si estás en crisis"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-muted",
			children: [
				"Estas apps no sustituyen la atención profesional. En México, la Línea de la Vida atiende las 24 horas en el",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "font-medium text-ink underline decoration-pink underline-offset-4",
					href: "tel:8009112000",
					children: "800 911 2000"
				}),
				". En una emergencia, llama al",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "font-medium text-ink underline decoration-pink underline-offset-4",
					href: "tel:911",
					children: "911"
				}),
				"."
			]
		})]
	});
}
function Shell({ tone = "cream", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cream text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#contenido",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:rounded-full focus:bg-ink focus:px-4 focus:py-3 focus:text-cream",
				children: "Saltar al contenido"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { tone }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "contenido",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Shell as a, PageIntro as i, CrisisNote as n, DivisionMark as r, AppMark as t };
