import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/content-DLrbi3b-.js
var import_jsx_runtime = require_jsx_runtime();
function StudioLogo({ tone = "ink", priority = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2.5 " + (tone === "cream" ? "" : "rounded-2xl bg-ink py-1.5 pr-3 pl-1.5"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/brand/ajolote.webp",
			alt: "Ajolote de Lito Labs",
			width: 201,
			height: 163,
			fetchPriority: priority ? "high" : void 0,
			className: "h-11 w-auto object-contain"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-lg font-semibold tracking-tight text-cream",
			children: "Lito Labs"
		})]
	});
}
function Glyph({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 32 32",
		className: "size-9",
		fill: "none",
		"aria-hidden": "true",
		children
	});
}
var stroke = {
	stroke: "currentColor",
	strokeWidth: 1.8,
	strokeLinecap: "round",
	strokeLinejoin: "round"
};
function AppGlyph({ name }) {
	if (name === "Ancla") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "8",
			r: "2",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 10v8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 16h12",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 16c0 6 2.2 9 4 9s4-3 4-9",
			...stroke
		})
	] });
	if (name === "MeltdownReset") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M8 18c2-6 6-8 8-8s6 2 8 8",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M10 22c1.6-4 3.4-5 6-5s4.4 1 6 5",
		...stroke
	})] });
	if (name === "SensoryMap") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M16 26s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "15",
		r: "2",
		...stroke
	})] });
	if (name === "Trato") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "3",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "21",
			cy: "13",
			r: "2.4",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 23c1-4 3.2-5.5 6-5.5s5 1.5 6 5.5",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M18 23c.6-2.6 2-3.8 4-3.8 1.6 0 2.8.8 3.6 2.4",
			...stroke
		})
	] });
	if (name === "Raíz") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 6v10",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 12c-4 1-6 4-7 8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 14c4 1 7 4 8 8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 18c-2 3-2 6-1 8M16 18c2 3 2.4 6 1.4 8",
			...stroke
		})
	] });
	if (name === "Loto y Lito") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glyph, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M8 24V10c4 2 6 2 8 0 2 2 4 2 8 0v14c-4 2-6 2-8 0-2 2-4 2-8 0z",
		...stroke
	}) });
	if (name === "Ajolote Fighters") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "5",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M12 10c0-3 2-5 4-4M16 9c1-4 4-5 5-2M19 12c3-1 6 0 6 2",
		...stroke
	})] });
	if (name === "Claro") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9 20h14",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M11 20l1.5-8h7L21 20",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M13 12V9h6v3",
			...stroke
		})
	] });
	if (name === "Halo") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "18",
		r: "5",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M10 10c1.6-2 3.6-3 6-3s4.4 1 6 3",
		...stroke
	})] });
	if (name === "Faro") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 6v3",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 12h8l2 4H10l2-4z",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M13 16v8h6v-8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 24h12",
			...stroke
		})
	] });
	if (name === "Morralla") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
		cx: "16",
		cy: "16",
		rx: "8",
		ry: "8",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M16 12v8M13.5 14.2h4.2a2 2 0 0 1 0 4H14",
		...stroke
	})] });
	if (name === "Nítida") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "4",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "16",
		cy: "16",
		r: "8",
		...stroke
	})] });
	if (name === "Linde") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M11 24V8h8",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "22",
			cy: "11",
			r: "3",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M22 8v1.2",
			...stroke
		})
	] });
	if (name === "Butaca") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M9 14h14v6a4 4 0 0 1-4 4H13a4 4 0 0 1-4-4v-6z",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M9 16V12a3 3 0 0 1 3-3h8",
		...stroke
	})] });
	if (name === "ilux") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 20h20",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M8 20l6-8 4 4 3-3 5 7",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "22",
			cy: "10",
			r: "2",
			...stroke
		})
	] });
	if (name === "Tlali") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 24V14",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 16c-2-4-6-5-8-3 3 0 5 2 8 3z",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 14c2-5 7-6 9-3-3 0-6 2-9 3z",
			...stroke
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 20c-3-2-6-2-8 0",
			...stroke
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Glyph, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M8 20h16M10 20V12h12v8",
		...stroke
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: "M13 12V9h6v3",
		...stroke
	})] });
}
var divisionName = {
	brisia: "Brisia",
	brujula: "Brújula",
	chispa: "Chispa",
	tuerca: "Tuerca",
	prisma: "Prisma",
	oficio: "Oficio"
};
function DivisionMark({ slug }) {
	const name = divisionName[slug] ?? slug;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: `/brand/division-${slug}.webp`,
		alt: `Marca de la división ${name}`,
		width: 306,
		height: slug === "brisia" ? 281 : 288,
		className: "h-28 w-auto shrink-0 object-contain"
	});
}
function AppMark({ division, name }) {
	if (name === "Faro") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/brand/app-faro.webp",
		alt: "Marca de la app Faro",
		width: 666,
		height: 666,
		className: "size-16 shrink-0 object-contain"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		"data-division": division,
		className: "slab relative grid size-16 shrink-0 place-items-center bg-ink text-cream",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppGlyph, { name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "accent-fill absolute right-1.5 bottom-1.5 size-1.5 rounded-full" })]
	});
}
var statusLabel = {
	prueba: "Prueba cerrada",
	desarrollo: "En desarrollo",
	maqueta: "Maqueta",
	pausa: "Próximamente"
};
var divisions = [
	{
		slug: "brisia",
		name: "Brisia",
		kicker: "Bienestar y regulación emocional",
		purpose: "Herramientas para bajar la intensidad y regularse en un momento difícil: sencillas, privadas y sin presión.",
		audience: "Adultos que buscan calmarse, incluidas personas autistas o neurodivergentes con sobrecarga sensorial.",
		promises: [
			"Una acción grande por pantalla cuando el momento es difícil.",
			"Sin sonidos, destellos ni vibración fuerte por defecto.",
			"Textos amables, sin rachas y sin culpa.",
			"Funcionan sin conexión. Los datos se quedan en el teléfono: se exportan o se borran con un toque.",
			"Nunca llevan anuncios."
		],
		caution: "No diagnostican ni sustituyen la terapia. Son un apoyo, no un tratamiento. Si hay una crisis, la app muestra la Línea de la Vida (800 911 2000) y el 911.",
		apps: [
			{
				name: "Ancla",
				summary: "Acciones concretas para sostenerte cuando la intensidad sube.",
				status: "prueba"
			},
			{
				name: "MeltdownReset",
				summary: "Respiración guiada, lenta, para volver a tu ritmo.",
				status: "prueba"
			},
			{
				name: "SensoryMap",
				summary: "Un mapa de lugares según cómo se sienten: luz, ruido, gente.",
				status: "prueba"
			}
		]
	},
	{
		slug: "brujula",
		name: "Brújula",
		kicker: "Práctica clínica y estudio de psicología",
		purpose: "Apoyo para la práctica clínica guiada y el estudio de psicología, con contenido riguroso y fuentes a la vista.",
		audience: "Psicólogos, estudiantes y adultos que practican con la guía de su terapeuta.",
		promises: [
			"Cada afirmación lleva su fuente. Nada de afirmaciones sueltas.",
			"No diagnostican ni etiquetan a la persona. No reemplazan la terapia.",
			"Sin datos de pacientes reales: ejemplos ficticios o anónimos.",
			"Si hay voz, se procesa en el teléfono.",
			"Nunca llevan anuncios."
		],
		caution: "Son material formativo o de práctica guiada, no un tratamiento. En temas sensibles, la app ofrece la Línea de la Vida (800 911 2000) y el 911.",
		apps: [{
			name: "Trato",
			summary: "Práctica de habilidades sociales, con retroalimentación neutral. Pensada para usarse junto con un terapeuta.",
			status: "prueba"
		}, {
			name: "Raíz",
			summary: "Lecturas de análisis funcional. Cada texto muestra autor y año.",
			status: "prueba"
		}]
	},
	{
		slug: "chispa",
		name: "Chispa",
		kicker: "Cuentos y juegos en familia",
		purpose: "Cuentos y juegos para disfrutar en familia, con arte original y raíces de Tepatitlán. Siempre con un adulto presente.",
		audience: "Niñas y niños con un adulto presente. La familia lee y juega junta.",
		promises: [
			"Pensadas para usarse con un adulto.",
			"Sin anuncios, sin compras escondidas y sin recolectar datos de menores.",
			"Arte original. Silencio a un toque.",
			"Botones grandes y letra clara."
		],
		apps: [{
			name: "Loto y Lito",
			summary: "Veinticuatro cuentos para leer juntos, con tiempo de lectura a la vista. Es la app más avanzada del estudio.",
			status: "prueba",
			featured: true
		}, {
			name: "Ajolote Fighters",
			summary: "Un juego de pelea con ajolotes. Sigue en desarrollo.",
			status: "desarrollo"
		}]
	},
	{
		slug: "tuerca",
		name: "Tuerca",
		kicker: "Herramientas útiles para el teléfono",
		purpose: "Herramientas que hacen una sola cosa, y la hacen bien: un teléfono más limpio, ordenado y tranquilo.",
		audience: "Cualquier persona con un teléfono Android, también quien tiene poca experiencia.",
		promises: [
			"Antes de borrar, bloquear o mover, muestran cuánto y qué va a pasar.",
			"Nada se borra ni se bloquea sin una confirmación clara. Hay papelera o deshacer.",
			"Cada permiso delicado se explica en palabras simples. Si lo niegas, la app sigue.",
			"Lo que hacen se queda en el teléfono."
		],
		apps: [
			{
				name: "Claro",
				summary: "Libera espacio y te dice cuánto soltaste, con papelera antes de borrar de verdad.",
				status: "prueba"
			},
			{
				name: "Halo",
				summary: "Baja el ruido de anuncios en el teléfono. Te explica el permiso que necesita antes de pedirlo.",
				status: "prueba"
			},
			{
				name: "Faro",
				summary: "Una pantalla de inicio sencilla, sin cajones escondidos.",
				status: "prueba"
			},
			{
				name: "Morralla",
				summary: "Práctica de microinversión en modo simulación. No mueve dinero de verdad.",
				status: "prueba"
			}
		]
	},
	{
		slug: "prisma",
		name: "Prisma",
		kicker: "Fotos y video, en orden y en privado",
		purpose: "Que las fotos y los videos estén en orden, y que lo privado se quede protegido dentro del teléfono.",
		audience: "Personas con galerías grandes que quieren orden, calma y privacidad.",
		promises: [
			"Todo se procesa en el teléfono. Las fotos privadas no salen de él.",
			"Hay papelera antes de borrar para siempre.",
			"Lo privado no se anuncia en la pantalla de inicio.",
			"Si un proceso es largo, muestra un avance real."
		],
		apps: [
			{
				name: "Nítida",
				summary: "Una galería tranquila, con papelera de 30 días.",
				status: "prueba"
			},
			{
				name: "Linde",
				summary: "Aparta en una carpeta privada, cifrada, lo que no quieres ver en la galería. Sigue en desarrollo.",
				status: "desarrollo"
			},
			{
				name: "Butaca",
				summary: "Un reproductor de video que usa los archivos que ya están en el teléfono.",
				status: "prueba"
			}
		]
	},
	{
		slug: "oficio",
		name: "Oficio",
		kicker: "Herramientas de trabajo para negocios en México",
		purpose: "Herramientas de trabajo para pequeños negocios y empresas de México, usables desde el primer día. Nuestra app estrella, ilux, ofrece gestión para guardias de seguridad mediante una suscripción mensual honesta: pagas por un servicio que se mantiene, actualiza y da soporte continuo.",
		audience: "Guardias, supervisores, cuadrillas de campo y quien atiende un mostrador.",
		promises: [
			"Textos claros y botones que se alcanzan con una mano.",
			"Lo que todavía no existe dice «Próximamente». No vendemos funciones que no están.",
			"Si hay suscripción, se explica antes: qué incluye, qué cuesta y que cubre mantenimiento, actualizaciones y soporte.",
			"Cada producto puede llevar su propia marca, y firma de Lito Labs."
		],
		apps: [
			{
				name: "ilux",
				summary: "Gestión para guardias de seguridad, con suscripción mensual clara. El pago cubre mantenimiento, actualizaciones y soporte. Hoy sigue en desarrollo y aún no está publicada.",
				status: "desarrollo"
			},
			{
				name: "Tlali",
				summary: "Para cuadrillas que cuentan agave. Hoy es una maqueta: todavía no es una app para instalar.",
				status: "maqueta"
			},
			{
				name: "Relevo",
				summary: "Organización de tareas y equipos. Funciona sin conexión, con recordatorios locales. Está en prueba cerrada y aún no está publicada.",
				status: "prueba"
			}
		]
	}
];
function getDivision(slug) {
	return divisions.find((division) => division.slug === slug);
}
var promises = [
	{
		title: "Privacidad",
		body: "Privacidad por defecto. Tus datos se quedan en tu dispositivo. Sin rastreo invasivo ni cuentas obligatorias."
	},
	{
		title: "Calma",
		body: "Diseño para la calma. Interfaces libres de adicción, scroll infinito o notificaciones manipuladoras."
	},
	{
		title: "Honestidad",
		body: "Transparencia radical. Explicamos qué hace cada app, qué datos usa y cómo se financia, sin letras chiquitas."
	},
	{
		title: "Accesibilidad",
		body: "Accesibilidad real. Diseñadas para funcionar sin internet y adaptadas para personas neurodivergentes o con baja alfabetización digital."
	},
	{
		title: "Precios claros",
		body: "Modelos de negocio justos. Pago único para herramientas personales, y suscripciones transparentes para software empresarial (como ilux), sin cobros ocultos."
	}
];
var yesItems = [
	"Aplicaciones Android en español que resuelven un problema real.",
	"Herramientas personales de pago único, sin cobros escondidos.",
	"Software de trabajo con suscripción clara, como ilux.",
	"Cuentos y juegos para la familia, con un adulto presente.",
	"Bienestar y formación, sin sustituir la atención profesional."
];
var noItems = [
	"Productos que compiten por tu atención o buscan engancharte.",
	"Rastreo invasivo, venta de datos o cuentas obligatorias.",
	"Copias de apps masivas en categorías ya saturadas.",
	"Promesas, precios o funciones que no están explicados.",
	"Lanzar más de lo que podemos cuidar."
];
var nav = [
	{
		to: "/",
		label: "Inicio"
	},
	{
		to: "/divisiones",
		label: "Divisiones"
	},
	{
		to: "/estado",
		label: "Estado"
	},
	{
		to: "/aliados",
		label: "Aliados"
	},
	{
		to: "/contacto",
		label: "Contacto"
	}
];
/** Apps que se muestran en la portada y en el formulario de probadores. */
var featuredApps = [
	{
		name: "ilux",
		division: "Oficio",
		slug: "oficio"
	},
	{
		name: "Faro",
		division: "Tuerca",
		slug: "tuerca"
	},
	{
		name: "Loto y Lito",
		division: "Chispa",
		slug: "chispa"
	},
	{
		name: "Relevo",
		division: "Oficio",
		slug: "oficio"
	}
];
//#endregion
export { featuredApps as a, noItems as c, yesItems as d, divisions as i, promises as l, DivisionMark as n, getDivision as o, StudioLogo as r, nav as s, AppMark as t, statusLabel as u };
