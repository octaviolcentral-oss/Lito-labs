import { a as promises, i as noItems, s as yesItems, t as divisions } from "./content-CtZlX-HB.mjs";
import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shell, r as DivisionMark } from "./site-Cc8zQIH8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DgEGxCn2.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		tone: "ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "on-ink bg-ink text-cream",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 pt-8 pb-16 md:px-8 md:pt-16 md:pb-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tracking-widest text-dim uppercase",
							children: "Lito Labs · Tepatitlán, Jalisco"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-3xl text-4xl font-semibold leading-tight md:text-6xl",
							children: "Apps en español para lo que nadie más está viendo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-6" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-lg text-dim",
							children: "Somos un estudio pequeño de apps Android, nacido en Tepatitlán de Morelos. Hacemos apps para las necesidades que las grandes empresas no ven o no consideran negocio."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/divisiones",
								className: "inline-flex min-h-12 items-center justify-center rounded-full bg-cream px-5 font-medium text-ink",
								children: "Ver las divisiones"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/estado",
								className: "inline-flex min-h-12 items-center justify-center rounded-full border border-dim px-5 font-medium text-cream",
								children: "Cómo van las apps"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-5xl px-5 py-14 md:px-8 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-semibold",
						children: "Quiénes somos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 max-w-3xl space-y-4 text-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Lito Labs es el estudio de apps de Octavio Ramírez, psicólogo en Tepatitlán. Creamos herramientas sencillas, tranquilas y privadas que le resuelven algo concreto a alguien concreto." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Una app de Lito Labs se mide por si de verdad le hizo la vida más fácil a quien la usa, no por cuánto tiempo lo tuvo pegado a la pantalla. Eso vale igual para liberar espacio en el teléfono, leer un cuento con tu hijo o calmarte en un mal momento." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-2xl border border-line bg-paper p-5 text-base",
								children: "Nuestra misión: crear apps sencillas, privadas y bien hechas en español para nichos pequeños y desatendidos, que resuelvan problemas reales sin cobrar con la atención ni con los datos de las personas."
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-14 md:px-8 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-semibold",
							children: "Lo que te prometemos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid gap-4 md:grid-cols-2",
							children: promises.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-2xl border border-line bg-paper p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-semibold",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-muted",
									children: item.body
								})]
							}, item.title))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-14 md:px-8 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-semibold",
							children: "Seis divisiones, un mismo oficio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-lg text-muted",
							children: "Cada división tiene su color y su gente. Todas firman «de Lito Labs» con el mismo ajolote."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid gap-4 md:grid-cols-2",
							children: divisions.map((division) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/divisiones/$slug",
								params: { slug: division.slug },
								"data-division": division.slug,
								className: "division-card flex items-center gap-5 rounded-2xl bg-paper p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DivisionMark, { slug: division.slug }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xl font-semibold",
										children: division.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-muted",
										children: division.kicker
									})]
								})]
							}) }, division.slug))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-5xl gap-4 px-5 py-14 md:grid-cols-2 md:px-8 md:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-paper p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold",
							children: "Sí hacemos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3",
							children: yesItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-l-4 border-pink pl-3",
								children: item
							}, item))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-paper p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold",
							children: "No hacemos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3",
							children: noItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-l-4 border-line pl-3 text-muted",
								children: item
							}, item))
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-5xl px-5 py-14 md:px-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-paper p-6 md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl font-semibold",
								children: "Con toda honestidad"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-3xl text-lg",
								children: "Ninguna app está publicada todavía. Casi todas ya funcionan y están en prueba. Preferimos publicar pocas apps bien hechas y bien cuidadas que muchas a medias."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/estado",
								className: "mt-6 inline-flex min-h-12 items-center font-medium underline decoration-pink underline-offset-4",
								children: "Ver el estado de cada app"
							})
						]
					})
				})
			})
		]
	});
}
//#endregion
export { Home as component };
