import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Shell, n as MailLink, r as PageIntro } from "./site-CyOmUcbv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacidad-CNWcxpx4.js
var import_jsx_runtime = require_jsx_runtime();
function Block({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-2xl font-semibold",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 max-w-3xl space-y-3 text-lg",
			children
		})
	] });
}
function Privacidad() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "Lenguaje sencillo",
		title: "Privacidad",
		lede: "Tus datos se quedan en tu teléfono. No los vendemos y no te seguimos por la web."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-10 px-5 py-12 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "Se quedan en tu dispositivo",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Las apps de Lito Labs guardan lo tuyo en el teléfono. Fotos, tareas, rondas o lo que uses para estar en calma no viaja a un servidor nuestro para que lo leamos." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "La función principal está pensada para servir sin conexión, siempre que se pueda." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Puedes exportar o borrar tus datos con un toque. Si niegas un permiso, la app sigue con lo que pueda hacer sin él." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "No vendemos datos, ni te rastreamos",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No vendemos datos a terceros. No hay anuncios. No hay analíticas que miren lo que haces dentro de la app." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Este sitio no usa cookies de publicidad ni de rastreo. No te pedimos que te registres para leerlo." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Si algún día contamos visitas, será con una herramienta sin cookies, que no te identifica. Hoy no hay ninguna." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "Cuando una app pide cuenta",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Casi ninguna app de Lito Labs pide cuenta. ilux sí puede pedirla, porque es una herramienta de trabajo para un equipo de guardias." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "En ese caso los datos van cifrados y protegidos. Solo ve lo necesario quien opera el servicio, y te decimos antes qué se guarda y para qué. No se usa para publicidad ni se vende." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "Niños, calma y trabajo",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Las apps para niños se usan con un adulto y con permiso de quien cuida. No recogen datos de menores, no tienen chat y no tienen compras escondidas." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Las apps de bienestar no diagnostican y no guardan expedientes. Los ejemplos son ficticios." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "Si nos escribes",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El correo o el formulario de contacto sirven para responderte. Usamos tu nombre, tu correo y lo que nos cuentes solo para eso. No los pasamos a una lista de anuncios." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Lito Labs, en Tepatitlán de Morelos, Jalisco, México. Dudas de privacidad: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailLink, { className: "font-medium text-ink underline decoration-pink underline-offset-4" }),
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base text-muted",
						children: "Texto vigente: octubre de 2026. Si cambia, lo diremos en esta misma página."
					})
				]
			})
		]
	})] });
}
//#endregion
export { Privacidad as component };
