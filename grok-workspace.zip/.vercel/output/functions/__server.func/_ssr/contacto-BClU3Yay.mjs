import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shell, i as PageIntro } from "./site-Cc8zQIH8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contacto-BClU3Yay.js
var import_jsx_runtime = require_jsx_runtime();
function Contacto() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "Tepatitlán de Morelos, Jalisco",
		title: "Contacto",
		lede: "Leemos lo que nos escriben. Si propones una necesidad, cuéntala con calma: quién la vive y qué le falta hoy."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-5 py-12 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "max-w-xl divide-y divide-line rounded-2xl border border-line bg-paper",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-5 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm font-medium tracking-wide text-muted",
							children: "Correo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-xl font-medium",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline decoration-pink underline-offset-4",
								href: "mailto:hola@litolabs.com",
								children: "hola@litolabs.com"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-5 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm font-medium tracking-wide text-muted",
							children: "Teléfono"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-xl font-medium",
							children: "Próximamente"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-5 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm font-medium tracking-wide text-muted",
							children: "Sitio"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-xl font-medium",
							children: "litolabs.com"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 max-w-xl text-muted",
				children: "No hay formulario que finja enviar el mensaje a otra parte. El botón abre tu correo, y el mensaje sale de ahí."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "mailto:hola@litolabs.com?subject=Hola%20Lito%20Labs",
				className: "mt-4 inline-flex min-h-12 items-center rounded-full bg-ink px-5 font-medium text-cream",
				children: "Escribir un correo"
			})
		]
	})] });
}
//#endregion
export { Contacto as component };
