import { J as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as divisions, n as DivisionMark, u as statusLabel } from "./content-DLrbi3b-.mjs";
import { i as Shell, r as PageIntro } from "./site-CyOmUcbv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/divisiones-vAsdQfZv.js
var import_jsx_runtime = require_jsx_runtime();
function Divisiones() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "El estudio",
		title: "Divisiones",
		lede: "Seis líneas de trabajo para necesidades distintas. El mismo estándar en todas: propósito, privacidad y cuidado."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-5xl space-y-5 px-5 py-12 md:px-8",
		children: divisions.map((division) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
			"data-division": division.slug,
			className: "division-card rounded-2xl bg-paper p-5 md:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DivisionMark, { slug: division.slug }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold",
							children: division.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: division.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3",
							children: division.purpose
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 flex flex-wrap gap-2",
							children: division.apps.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-full border border-line px-3 py-1 text-sm font-medium",
								children: [app.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [" · ", statusLabel[app.status]]
								})]
							}, app.name))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/divisiones/$slug",
							params: { slug: division.slug },
							className: "mt-4 inline-flex min-h-12 items-center font-medium underline decoration-pink underline-offset-4",
							children: ["Entrar a ", division.name]
						})
					]
				})]
			})
		}, division.slug))
	})] });
}
//#endregion
export { Divisiones as component };
