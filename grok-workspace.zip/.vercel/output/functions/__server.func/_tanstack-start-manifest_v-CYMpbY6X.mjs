//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CYMpbY6X.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/aliados",
			"/contacto",
			"/estado",
			"/privacidad",
			"/divisiones/$slug",
			"/divisiones/"
		],
		preloads: ["/assets/index-B0U1odkq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B0U1odkq.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-hbidK5wq.js", "/assets/site-B9Mcmhrd.js"]
	},
	"/aliados": {
		filePath: "/workspace/src/routes/aliados.tsx",
		children: void 0,
		preloads: ["/assets/aliados-CnKBkR5n.js", "/assets/site-B9Mcmhrd.js"]
	},
	"/contacto": {
		filePath: "/workspace/src/routes/contacto.tsx",
		children: void 0,
		preloads: ["/assets/contacto-DkD6ocJn.js", "/assets/site-B9Mcmhrd.js"]
	},
	"/estado": {
		filePath: "/workspace/src/routes/estado.tsx",
		children: void 0,
		preloads: ["/assets/estado-C61hjgDM.js", "/assets/site-B9Mcmhrd.js"]
	},
	"/privacidad": {
		filePath: "/workspace/src/routes/privacidad.tsx",
		children: void 0,
		preloads: ["/assets/privacidad-Bxx1QicS.js", "/assets/site-B9Mcmhrd.js"]
	},
	"/divisiones/$slug": {
		filePath: "/workspace/src/routes/divisiones/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-C6btAFer.js", "/assets/site-B9Mcmhrd.js"]
	},
	"/divisiones/": {
		filePath: "/workspace/src/routes/divisiones/index.tsx",
		children: void 0,
		preloads: ["/assets/divisiones-BdnSoSnO.js", "/assets/site-B9Mcmhrd.js"]
	}
} });
//#endregion
export { tsrStartManifest };
