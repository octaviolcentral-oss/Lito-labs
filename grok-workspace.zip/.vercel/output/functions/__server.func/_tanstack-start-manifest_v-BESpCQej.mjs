//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BESpCQej.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/aliados",
			"/contacto",
			"/estado",
			"/privacidad",
			"/divisiones/$slug",
			"/divisiones/"
		],
		preloads: ["/assets/index-CSfiDDv4.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CSfiDDv4.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CmuwSjb_.js", "/assets/site-Dn0QiSGU.js"]
	},
	"/aliados": {
		filePath: "/workspace/src/routes/aliados.tsx",
		children: void 0,
		preloads: ["/assets/aliados-pNTe-RGI.js", "/assets/site-Dn0QiSGU.js"]
	},
	"/contacto": {
		filePath: "/workspace/src/routes/contacto.tsx",
		children: void 0,
		preloads: ["/assets/contacto-jL6_RnzK.js", "/assets/site-Dn0QiSGU.js"]
	},
	"/estado": {
		filePath: "/workspace/src/routes/estado.tsx",
		children: void 0,
		preloads: ["/assets/estado-CgKc-kin.js", "/assets/site-Dn0QiSGU.js"]
	},
	"/privacidad": {
		filePath: "/workspace/src/routes/privacidad.tsx",
		children: void 0,
		preloads: ["/assets/privacidad-CyZLVRSj.js", "/assets/site-Dn0QiSGU.js"]
	},
	"/divisiones/$slug": {
		filePath: "/workspace/src/routes/divisiones/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-DaE6PWwM.js", "/assets/site-Dn0QiSGU.js"]
	},
	"/divisiones/": {
		filePath: "/workspace/src/routes/divisiones/index.tsx",
		children: void 0,
		preloads: ["/assets/divisiones-BNYwjKdW.js", "/assets/site-Dn0QiSGU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
