import { J as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as DivisionMark, t as AppMark, u as statusLabel } from "./_ssr/content-DLrbi3b-.mjs";
import { n as Route } from "./_ssr/router-B68TUUdD.mjs";
import { i as Shell, r as PageIntro, t as CrisisNote } from "./_ssr/site-CyOmUcbv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-Qm45Drv4.js
var import_jsx_runtime = require_jsx_runtime();
function DivisionPage() {
	const { division } = Route.useLoaderData();
	const showCrisis = division.slug === "brisia" || division.slug === "brujula";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: division.kicker,
		title: division.name,
		lede: division.purpose
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-10 px-5 py-12 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DivisionMark, { slug: division.slug }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-2xl pt-2 text-lg text-muted",
					children: division.audience
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold",
					children: "Cómo se nota"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-3",
					children: division.promises.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						"data-division": division.slug,
						className: "accent-border border-l-4 pl-3",
						children: item
					}, item))
				})
			] }),
			division.caution ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border border-line bg-paper p-5 text-base",
				children: division.caution
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold",
					children: "Apps"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "pink-rule mt-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 grid gap-4",
					children: division.apps.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4 rounded-2xl border border-line bg-paper p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppMark, {
							division: division.slug,
							name: app.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-semibold",
								children: app.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-line px-3 py-1 text-sm font-medium",
									children: statusLabel[app.status]
								}), app.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-pink px-3 py-1 text-sm font-medium",
									children: "La más avanzada"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: app.summary
							})
						] })]
					}, app.name))
				})
			] }),
			showCrisis ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrisisNote, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/divisiones",
				className: "inline-flex min-h-12 items-center font-medium underline decoration-pink underline-offset-4",
				children: "Todas las divisiones"
			})
		]
	})] });
}
//#endregion
export { DivisionPage as component };
