#!/usr/bin/env python3
"""Hand-built Lito Labs axolotl mark. Flat fills only — no gradients, no shadows."""
import math
from pathlib import Path

CREAM = "#FDF6E9"
CHAR = "#33383E"
PINK = "#F2A7B5"


def petal(cx, cy, rx, ry, rot):
    return (
        f'<ellipse cx="{cx:.2f}" cy="{cy:.2f}" rx="{rx}" ry="{ry}" '
        f'transform="rotate({rot:.1f} {cx:.2f} {cy:.2f})"/>'
    )


# Three rounded gill petals fanning from the back of the head.
# Angle 0° is +x; SVG y grows downward, so negative angles point up.
origin = (46, 50)
petals = []
for ang, dist, ry in ((-158, 16.5, 11.2), (-120, 17.5, 12.0), (-84, 16.0, 11.4)):
    rad = math.radians(ang)
    cx = origin[0] + math.cos(rad) * dist
    cy = origin[1] + math.sin(rad) * dist
    petals.append(petal(cx, cy, 6.4, ry, ang + 90))

# Open curling tail: a tapered hook, one turn, no self-crossing.
# Root sits inside the belly; the tip curls back upward.
tail = """
M 50 68
C 34 66 18 74 18 86
C 18 97 34 99 42 90
C 46 85 38 80 32 84
C 26 88 24 92 28 90
C 34 87 36 82 30 80
C 22 77 32 70 48 72
Z
""".replace("\n", " ").strip()

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <rect width="100" height="100" rx="22" fill="{CREAM}"/>
  <g fill="{PINK}">
    {"".join(petals)}
  </g>
  <g fill="{CHAR}">
    <path d="{tail}"/>
    <ellipse cx="56" cy="66" rx="15" ry="11.5" transform="rotate(-8 56 66)"/>
    <!-- wide, blunt head: one flat capsule, not a bolted-on snout -->
    <rect x="40" y="35" width="48" height="28" rx="14"/>
  </g>
  <circle cx="74" cy="47.5" r="4.2" fill="{CREAM}"/>
</svg>
'''

Path("/workspace/.grok/mark.svg").write_text(svg)
print("wrote mark.svg")
